
# LAB-SOP (Local) — Instagram-style Mobile App (Expo, React Native)

Run:
```bash
npm install
npx expo start
```

Tabs: Home, Explore, Create (spec composer), Reels (video), Messages, Profile.
Data is stored locally (AsyncStorage). Replace sample media URLs with your own if needed.
